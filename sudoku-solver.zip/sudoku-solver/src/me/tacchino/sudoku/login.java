package me.tacchino.sudoku;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.LinearGradientPaint;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Point2D;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class login {
    
    
    public static void main(String[] args) {
        final JFrame frame = new JFrame("SUDOKU");
        frame.setBounds(500,400,450,400);


        JLabel l4=new JLabel("Welcome to the world of SUDOKU");
        l4.setBounds(60,20,290,100);
        l4.setVisible(true);
        l4.setFont(new Font("Times New Roman", Font.BOLD, 18));



        JLabel l1=new JLabel("Enter your Name - ");
        l1.setBounds(40,100,150,100);
        l1.setVisible(true);

        

        

        final JTextField t2=new JTextField();
        t2.setBounds(180,140,150,20);
        t2.setVisible(true);

        JButton b1=new JButton("Start");
        b1.setBounds(200,180,100,40);
        b1.setVisible(true);

        

        frame.add(l1);
        
        frame.add(t2);
        frame.add(b1);
        
        frame.add(l4);



        

        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                    
                    
                    
                    
                    if(t2.getText().toString().isEmpty())
                    {
                        JOptionPane.showMessageDialog(frame, "Enter your name", "Warning", JOptionPane.ERROR_MESSAGE);
                            
                    }
                    else
                    {
                        

                        JOptionPane.showMessageDialog(frame, "Welcome "+t2.getText().toString(), "Successfull", JOptionPane.INFORMATION_MESSAGE);
                        SudokuStart st=new SudokuStart();
                        st.setVisible(true);
                    }
                    
                    

                   
                    
                    
                    
            }

            

            
        });

        Color hexColor = new Color(0xFFDDE1);
        frame.getContentPane().setBackground(hexColor);        



        frame.setLayout(null);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    
        
}
}