package me.tacchino.sudoku;
public class SudokuStart {
	public static void main (String args[]){
		GUI gui = new GUI();
		gui.createGUI();
	}

	public void setVisible(boolean b) {
		GUI gui = new GUI();
		gui.createGUI();
		
	}
}


